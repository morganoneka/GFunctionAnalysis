# Spatial Analysis using G-Function Analysis

The G-function is a useful tool for analyzing infiltration of cell types from IHC data. This code provides a workflow for analyzing and visualizing these results.

## Required to run
- Snakemake
- The following R libraries:
  - ggplot2
  - spatstat
  - matlab

( possibly several others I'll double-check )

## Input
### Input File
For this analysis, you will need ONE file with all of these columns:
- X coordinate
- Y coordinate
- Phenotype(s)
- Patient
- Sample

This file can be a .csv, .txt, or other file that has one delimiter.

The important part is that this must be ONE file. If your data is separated by patient or by individual sample, it must be combined into one file.

### Interactions JSON
This indicates what interactions you are interested in analyzing.

#### Reference vs. Non-Reference
Each interaction contains a "reference" and "non-reference" cell type. The Gcross analysis will calculate the infiltration of non-reference cells into reference cells. For example, suppose you were interested in quantifying the infiltration of CTLs into epithelial cells. Epithelial cells would be the reference cells, and CTLs would be the non-reference cells.

Each cell type is a list of dictionaries.

#### Multiple Cell Types
Reference and non-reference cells can have require specific values of multiple columns.

The example below shows the definition of a CTL. For this sample, we want a cell to be considered a CTL if its value in the CD8 column is "CD8+" **AND** if its value in the CD3 column is "CD3+".

This results in the non-reference value mapping to a list of one dictionary. Each key in the dictionary maps to the value it must have to be considered a CTL.

``` json
"Non-Reference" : [ {"CD8" : ["CD8+"], "CD3" : ["CD3+"]} ]
```

Cell types can also require only one of multiple conditions to be true.

The example below shows the definition of an epithelial cell. For this sample, a cell is considered to be epithelial if its value in the Ecadherin column is "ECadherin+" **OR** its value in the Pancytokeratin column is "Pancytokeratin+".

In this case, the reference value maps to a list of multiple dictionary. Within each dictionary, each key in the dictionary maps to the value it must have to fulfill one of the definitions of an epithelial cell.

``` json
"Reference" : [ {"ECadherin" : ["ECadherin+"]} , {"Pancytokeratin" : ["Pancytokeratin+"]}]
```

## How to Run
Included in this repository is a Snakemake file that will run all of the analysis. The first step is to **create a directory** for your output.

Next, you'll want to **edit the config file** so the Snakemake file knows where all the relevant files are. These are the values in the Snakemake file:
- **CODE_LOCATION**: The directory that contains all of the Gcross code. This will be the location where this repo was cloned to.
- **DATA_DIR**: The directory where all your output will be saved
- **INPUT_FILE**: The path to the file being analyzed.

## Current Workflow

### XY Plotting
For each sample, and for each interaction, a plot will be generated showing the XY coordinates of the reference and non-reference cells in that sample.

### Gcross Analysis
For each interaction, a .csv file will be generated containing the Gcross values for each patient.

### Gcross Plotting
For each sample and interaction, a plot will be generated of that Gcross curve

### AUC Calculation
One .csv file will be generated containing the AUC for each interaction at 60, 120, and 200 pixels.

## Editing the Snakemake file
The Snakemake file can be edited for any analysis requiring input outside the default

### Samplewise vs. Imagewise

### Custom radius  


###
